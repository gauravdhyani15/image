import { Component, HostListener } from '@angular/core';
import { CommonModule } from '@angular/common';
import { ConfigDisplayComponent } from "../config-display/config-display.component";

@Component({
  selector: 'app-header',
  imports: [CommonModule,ConfigDisplayComponent],
  templateUrl: './header.component.html',
  styleUrl: './header.component.css'
})
export class HeaderComponent {
  screenWidth = window.innerWidth;

  @HostListener('window:resize', ['$event'])
  onResize(event: Event) {
    this.screenWidth = (event.target as Window).innerWidth;
  }

  screenIsSmall(): boolean {
    return this.screenWidth < 768; // Tailwind's 'md' breakpoint
  }
  sidebarOpen = true;

  toggleSidebar() {
    this.sidebarOpen = !this.sidebarOpen;
  }

}
