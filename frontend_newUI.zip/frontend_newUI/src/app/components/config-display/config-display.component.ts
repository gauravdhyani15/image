import { Component } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormBuilder, FormGroup, ReactiveFormsModule, FormsModule, Validators } from '@angular/forms';
import {
  trigger,
  style,
  transition,
  animate,
} from '@angular/animations';

import { UploadInstallerService } from '../../services/upload-installer.service';
import { LoaderComponent } from '../loader/loader.component';

@Component({
  selector: 'app-config-display',
  standalone: true,
  imports: [CommonModule, ReactiveFormsModule, FormsModule, LoaderComponent],
  templateUrl: './config-display.component.html',
  styleUrl: './config-display.component.css',
  animations: [
    trigger('fadeSlide', [
      transition(':enter', [
        style({ opacity: 0, transform: 'translateY(16px)' }),
        animate('300ms ease-out', style({ opacity: 1, transform: 'translateY(0)' })),
      ]),
      transition(':leave', [
        animate('200ms ease-in', style({ opacity: 0, transform: 'translateY(-16px)' })),
      ]),
    ]),
  ],
  providers: [UploadInstallerService],
})
export class ConfigDisplayComponent {
  appForm!: FormGroup;

  // Step control: 'upload' -> 'config' -> 'submit'
  currentStep: 'upload' | 'config' | 'submit' = 'upload';

  // File upload info
  uploadedFileName = '';
  uploadedFileType!: 'msi' | 'exe';
  isLoader: boolean = false;
  psadtVersion!: 'V 3.10.0' | 'V 4.0.6';
  versions = [
    { value: 'V 3.10.0', label: 'V 3.10.0' },
    { value: 'V 4.0.6', label: 'V 4.0.6' },
    // Add more versions as needed
  ];

  // Template version selector
  selectedVersion = 'V 3.10.0';

  // Templates for different versions and file types
  scriptTemplates = {
    'V 3.10.0': {
      msi: {
        install: "Execute-MSI -Action 'Install' -Path 'filename' -Parameters '/quiet /norestart'", // file name ayga yaha par
        uninstall: 'Execute-MSI -Action "Uninstall" -Path "filename" -Parameters "/quiet /norestart"', // file name ayga yaha par
        repair: 'Execute-MSI -Action "Repair" -Path "filename" -Parameters "/quiet /norestart"', // file name ayga yaha par
      },
      exe: {
        install: 'Execute-Process -Path "filename" -Parameters "/S" -WindowStyle "Hidden"',
        uninstall: 'Execute-Process -Path "filename" -Parameters "/uninstall" -WindowStyle "Hidden"',
        repair: 'Execute-Process -Path "filename" -Parameters "/repair" -WindowStyle "Hidden"',
      },
    },
    'V 4.0.6': {
      msi: {
        install: 'Start-ADTMsiProcess -Action "Install" -FilePath "MSINAME.msi"',
        uninstall: 'Start-ADTMsiProcess -Action "Uninstall" -FilePath "MSINAME.msi"',
        repair: 'Start-ADTMsiProcess -Action "Repair" -FilePath "MSINAME.msi"',
      },
      exe: {
        install: 'Start-ADTProcess -FilePath "MSINAME" -ArgumentList "/S"',
        uninstall: 'Start-ADTProcess -FilePath "MSINAME.exe" -ArgumentList "/uninstall /S" -WindowStyle "Hidden"',
        repair: 'Start-ADTProcess -FilePath "MSINAME.exe" -ArgumentList "/repair /S" -WindowStyle "Hidden"',
      },
    },
  };

  constructor(
    private fb: FormBuilder,
    private uploadInstallerService: UploadInstallerService
  ) {}

  ngOnInit(): void {
    // Initialize form with defaults
    this.appForm = this.fb.group({
      appName: ['', Validators.required],
      appVersion: ['', Validators.required],
      publisher: ['', Validators.required],
      publisherEmail: ['', [Validators.required, Validators.email]],
      msiName: ['',Validators.required],
      description: [''], // optional
      installScript: ['', Validators.required],
      uninstallScript: ['', Validators.required],
      repairScript: ['', Validators.required],
    });
 
  }

  // Called when form is submitted
  onSubmit(): void {
    this.uploadInstallerService.postAppDetails(this.appForm.value).subscribe({
      next: (response:any) => {
          this.currentStep = 'submit';
      },
      error: (error:any) => {
          this.currentStep = 'config';
      },
    });
  }

  // Go back to upload step
  routeToStart(): void {
    this.currentStep = 'upload';
  }

  // Triggered when a file is selected
  handleFileUpload(event: Event): void {
    const input = event.target as HTMLInputElement;
    const file = input.files?.[0];
    if (!file) return;
   this.updateScriptTemplates(); //////////////////////////////////////////////////needsw tsdvgsdfseagsdgsehgrshsfdhgbsd
    this.uploadedFileType = file.name.endsWith('.msi') ? 'msi' : 'exe';
    this.uploadMsiFile(file, file.name);
  }

  // Uploads the file and moves to config step
  uploadMsiFile(file: File, fileUploadedName: string): void {
    this.isLoader = true;

    this.uploadInstallerService.uploadMsiFile(file).subscribe(
      (response: any) => {
        this.isLoader = false;
        this.currentStep = 'config';
        this.updateScriptTemplates(); 
        console.log('Server response:', response);
        const versionInfo = response?.fileInfo?.versionInfo;

        if (versionInfo) {
          this.appForm.patchValue({
            appName: versionInfo.ProductName || '',
            appVersion: versionInfo.ProductVersion || '',
            publisher: versionInfo.Manufacturer || '',
            msiName:fileUploadedName
            
           
          });
        }
      },
      (error: any) => {
        this.isLoader = false;
        this.currentStep = 'config';
        console.error('Upload failed:', error);
        // TODO: Show a proper error message to user (e.g., toast/alert)
      }
    );
  }

  // Auto-fill install/uninstall/repair scripts based on selected version and file type
  updateScriptTemplates(): void {
    console.log('Selected version:', this.psadtVersion);
    console.log('Uploaded file type:', this.uploadedFileType);
    const templates = this.scriptTemplates[this.psadtVersion as 'V 3.10.0' | 'V 4.0.6'][this.uploadedFileType as 'msi' | 'exe'];
  console.log('Templates:', templates);
    this.appForm.patchValue({
      installScript: templates.install,
      uninstallScript: templates.uninstall,
      repairScript: templates.repair,
    });
  }

  getSelectedVersion(event: any): void {
    this.psadtVersion = event.target.value;
  }
}
