import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders, HttpEvent, HttpEventType, HttpResponse } from '@angular/common/http';
import { catchError, filter, map, Observable, throwError } from 'rxjs';
import { environment } from '../../enviroments/environment'; // 👈 import env

@Injectable({
  providedIn: 'root',
})
export class UploadInstallerService {
  private baseUrl = environment.apiBaseUrl; // 👈 use env var
  public authToken = ''; // Token needs to be set from somewhere

  constructor(private http: HttpClient) {}

  // Headers including Bearer token
  private getHeaders(): HttpHeaders {
    return new HttpHeaders({
      Authorization: `Bearer ${this.authToken}`,
    });
  }

  public uploadMsiFile(data: File): Observable<HttpEvent<any>> {
    const formData = new FormData();
    formData.append('file', data);

    return this.http.post<any>(this.baseUrl, formData, {
    headers: this.getHeaders(),
    reportProgress: true,
    observe: 'events'
  }).pipe(
    filter((event): event is HttpResponse<any> => event.type === HttpEventType.Response), // only final response
    map((event) => event.body), // extract the body
    catchError((error) => throwError(() => error))
  );
  }

  private apiUrl = 'https://aap.automationplatform.mhf.mhc/api/v2/job_templates/10/launch/'; // Base API URL /// make it env 
  private authTokens = 'DWvZmj4YFjPSyBx9EyceXLbl6oWWFx'; // make it env


  public postAppDetails( data:any): Observable<any> {
   

    const formdata = data; // Assuming data is the form data object

    // Constructing the payload based on the form data
    // You can modify the payload structure as per your requirements


   const payload = {
  extra_vars: {
    appname: formdata.appName || '',
    appversion: formdata.appVersion || '',
    appvendor: formdata.publisher || '',
    authname: formdata.appName || 'Default', // Using appName as fallback
    description: formdata.description || '',
    email_id: formdata.publisherEmail || '',
    disp_name: formdata.msiName || '',
    repair_block: formdata.repairScript || '',
    uninstall_block: formdata.uninstallScript || '',
    install_block: formdata.installScript || ''
  }
};



    const headers = new HttpHeaders({
      Authorization: `Bearer ${this.authTokens}`, 
      'Content-Type': 'application/json', 
    });

    return this.http.post(this.apiUrl, payload, { headers }).pipe(
      catchError((error) => {
        return throwError(() => error);
      })
    );
  }
}
