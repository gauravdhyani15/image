export const environment = {
    production: false,
    apiBaseUrl: 'https://packagebuilder.mhf.mhc/api/upload/',
  };